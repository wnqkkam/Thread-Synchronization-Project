// C program to demonstrate e-commerce stock balance synchronization issue
#include <stdio.h> 
#include <pthread.h> 
#include <unistd.h>

int balance = 2;	//initial stock balance is 2 units

//thread t0 does the following
void* customer_0(void* arg)		
{ 
	int t = balance;
	sleep(0.1);	//simulate time taken to read. Do not remove this line.
	if(balance > 0)
		balance = t - 1;	
} 

//thread t1 does the following
void* customer_1(void* arg)		
{ 
	int t = balance;
	sleep(0.1);	//simulate time taken to read. Do not remove this line.
	if(balance > 0)
		balance = t - 1;
} 

int main() 
{ 
	//these values are used to identify thread number
	int thread0_id=0, thread1_id=1; 

	//intialize two variables type pthread_t called t0 and t1
	pthread_t t0, t1; 
	
	//create two threads, passing thread number as the forth argument
	pthread_create(&t0,NULL,customer_0,&thread0_id); 
	pthread_create(&t1,NULL,customer_1,&thread1_id); 

	//join two threads after they finished running
	pthread_join(t0,NULL); 
	pthread_join(t1,NULL); 
	
	printf("Final stock balance: %d\n", balance);

	return 0; 
} 
