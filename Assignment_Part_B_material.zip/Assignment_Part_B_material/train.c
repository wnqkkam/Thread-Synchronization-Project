// C program to simulate traffic and train crossing railway
// Reference: https://www.geeksforgeeks.org/use-posix-semaphores-c/
#include <stdio.h> 
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h> 


void* train(void* arg) 
{ 
	while(1){
		printf("\n The railway gate is closed\n"); 
	
  		//critical section 
		printf("\n The train is crossing\n");
		sleep(1);	//train crossing for 1 second
      
		printf("\n The railway gate is opened\n"); 		
		sleep(5);	//the next train will arrive every 5 seconds
	}	
} 

void* car(void* arg) 
{ 
	while(1){
		printf("\n The cars are crossing the railway\n"); 
		sleep(1);		
  	}
} 
 

int main() 
{ 
	//these values are used to identify thread number
	int thread0_id=0, thread1_id=1; 
	
	pthread_t t0,t1; 
	
	//create three threads, passing thread number as the forth argument
	pthread_create(&t0,NULL,car,&thread0_id); 
	pthread_create(&t1,NULL,train,&thread1_id); 

	//join two threads after they finished running
	pthread_join(t0,NULL); 
	pthread_join(t1,NULL); 

	return 0; 
} 
